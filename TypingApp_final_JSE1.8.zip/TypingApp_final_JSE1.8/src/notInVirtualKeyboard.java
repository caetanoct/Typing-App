
public class notInVirtualKeyboard extends Exception {
	public notInVirtualKeyboard(String message) {
		super(message);
	}
}
